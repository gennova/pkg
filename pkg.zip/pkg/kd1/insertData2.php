<?php

include ('../function')
$kode=$_GET['kodeuser'];

$kodetiga = $_GET['tiga'];
$kodeempat = $_GET['empat'];