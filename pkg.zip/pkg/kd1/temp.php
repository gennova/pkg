
<table align="left" border = 1>

  <tr>
    <th>No</th>
    <th>Pertanyaan</th>
    
    <th>Bobot</th>
  </tr>

  <tr>
    <td>A</td>
    <th>Persiapan Pembelajaran</th>
  </tr>

  <tr>
    <td>1</td>
    <td>Kelengkapan administrasi pengajaran (prota , prosem,silabus,rpp)</td>
  </tr>
</table>
